# Features to add and Problems I intend to solve in the future.

## Problem
1. Latency issue i view button when you click it for the first time.
2. For syncing to occur after grouping the tabs into a group, users **must** open the respective tabs again by clicking the respective group name.
3. Duplicate group-name is allowed.

## Features
1. alert to confirm the deletion of the group
2. Edit button to add or remove the tabs from the group.
3. Pause the video.